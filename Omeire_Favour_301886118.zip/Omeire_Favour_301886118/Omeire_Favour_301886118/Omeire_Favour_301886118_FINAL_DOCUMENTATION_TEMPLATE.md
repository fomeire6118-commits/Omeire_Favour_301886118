# MIT 8103 Advanced Database Systems: Portfolio Documentation

**Name:** Favour Amarachi Omeire **Matric No:** 2025/C/MIT/1766
**GitHub repository:** https://github.com/fomeire6118-commits/Omeire_Favour_301886118/upload/main (access granted to assessor)

## 1. Selected Case Study
- **Organisation:** Favoured Market Place
- **Nature of business/system:** Retail of baking products and provisions; sales and inventory database.
- **Users:** owner, shop attendants, delivery staff.
- **Major data stored:** products, suppliers, customers, orders, payments, purchases with expiry dates, stock movements.
- **Key operations:** record sales, update stock, flag low stock/expiry, rank best sellers, measure profit.

## 2. Portfolio 1: Database Design and Modelling
The relational database contains staff, categories, suppliers, products number of tables are 12, they  are bounded by these relationship: PRIMARY KEYS which uniquely identifies each rows, FOREGIN KEY points to a row in another table, CHECK is a rule that must be obeyed, UNIQUE indicates that no two rows have the same value and NOT NULL indicates that the cell cannot be left empty. Key constraints (PK, FK, CHECK stock >= 0), normalisation to 3NF with the one deliberate choice (unit_price stored on order lines). *Insert ER diagram screenshot.*

## 3. Portfolio 2: Query Processing and Optimisation
Each query answers the questions: Which five products earn the most money? (JOIN + GRUOP BY + ORDER BY), how much did the shop sell each month?, which product needs restocking now? Which stock batches expires within the next 30 days?  what's the profit and profit margin per product?, rank customers by how much they have spent (WINDOW FUNCTION), which registered customers have never bought anything? (LEFT JOIN), customers who spent MORE than the average customer (CTE + subquery), sales by channel using the saved VIEW from Portfolio 1.

## 4. Portfolio 3: Transactions and Concurrency
A transaction is a group of group of steps that must all succeed or all be undone, BEGIN starts one, COMMIT saves it and ROLLBACK undoes it. While concurrency ensures that when two people are using the database at the same time, there is no error.

## 5. Portfolio 4: NoSQL and Advanced Data Models
MongoDB document is used to demonstrate a document-oriented representation of the same business. Goods are purchased by customers through different channels, highlighted include: delivery, walk-in and WhatsApp. This model is suitable for flexible product attributes and aggregates read.

## 6. Portfolio 5: Distributed and Cloud Database Exercise
Distributed database is very essential to this business because it serves as a backup system to maintain data and also sustains a wide range of data over various locations. Replication keeps copies of the data on various servers. This mechanism is represented through partitioning.

## 7. Individual Technical Reflection
The Starter file was quite detailed but coming from a real world senerio i had to input real figures from Favoured Market Place. The hardest experience was understanding the codes, I was able to conquer this through deeper study. One interesting aspect was the consistency in order of codes as i kept learning and progressing. As the business grows,i believe there should also be advancement in IT utilization and cloud computing, this will greatly help manage and maximise profit rom both the owner, attendant and customer.

## 8. References and Acknowledged Resources
- PostgreSQL Global Development Group. *PostgreSQL Documentation.* https://www.postgresql.org/docs/
- MongoDB, Inc. *MongoDB Manual.* https://www.mongodb.com/docs/
- Sample data: adapted from my business records, anonymised.

## 9. AI Use Declaration
**AI tool used:** Claude (Anthropic).

**What it was used for:** Generating starter SQL/MongoDB scripts and README explanations for the case study, and explaining database concepts in plain language.

**How I reviewed, corrected, tested and verified the output:** I ran every script myself including github, replaced the sample data with my own products/prices, created the screenshots and timings from my own machine, and wrote the final documentation myself.

