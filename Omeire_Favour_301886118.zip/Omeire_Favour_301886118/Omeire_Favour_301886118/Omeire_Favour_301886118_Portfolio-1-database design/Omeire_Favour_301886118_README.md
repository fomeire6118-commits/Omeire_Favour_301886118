# Portfolio 1: Database Design and Modelling

## 1. Case Study Statement (put this at the START of your documentation)

| Item | Description |
|---|---|
| **Organisation / scenario** | Favoured Market Place, a small retail business in Nigeria selling baking products (flour, sugar, margarine, yeast, flavourings, cake boxes) and general provisions. |
| **Nature of the business/system** | A retail sales and inventory database that records what is sold, to whom, through which channel (walk-in, WhatsApp, delivery), how it was paid for, and how stock is bought and monitored. |
| **Users of the database** | The owner (reports, pricing, restocking), shop attendants (record sales), and delivery staff (update delivery orders). |
| **Major data stored** | Products and categories, suppliers, customers, orders and order items, payments, purchases with expiry dates, stock movements, and low-stock alerts. |
| **Key operations supported** | Record a sale, update stock automatically, take payment, receive new stock, flag items that are low or near expiry, rank best-selling products, and measure profit and customer spending. |

## 2. ER Diagram

```mermaid
erDiagram
    CATEGORIES ||--o{ PRODUCTS : groups
    SUPPLIERS  ||--o{ PRODUCTS : supplies
    SUPPLIERS  ||--o{ PURCHASES : receives_orders_from_us
    PURCHASES  ||--|{ PURCHASE_ITEMS : contains
    PRODUCTS   ||--o{ PURCHASE_ITEMS : bought_as
    CUSTOMERS  |o--o{ ORDERS : places
    STAFF      ||--o{ ORDERS : records
    ORDERS     ||--|{ ORDER_ITEMS : contains
    PRODUCTS   ||--o{ ORDER_ITEMS : sold_as
    ORDERS     ||--o{ PAYMENTS : paid_by
    PRODUCTS   ||--o{ STOCK_MOVEMENTS : logged_in
    PRODUCTS   ||--o{ LOW_STOCK_ALERTS : triggers

    PRODUCTS {
        int product_id PK
        string sku UK
        string name
        int category_id FK
        int supplier_id FK
        numeric cost_price
        numeric selling_price
        int stock_qty
        int reorder_level
    }
    CUSTOMERS {
        int customer_id PK
        string full_name
        string phone UK
    }
    ORDERS {
        int order_id PK
        int customer_id FK
        int staff_id FK
        timestamptz order_date
        string channel
        string status
    }
    ORDER_ITEMS {
        int order_id PK,FK
        int product_id PK,FK
        int quantity
        numeric unit_price
    }
    PAYMENTS {
        int payment_id PK
        int order_id FK
        numeric amount
        string method
    }
```

## 3. Relational Schema (summary)

`PK` = primary key, `FK` = foreign key, `UK` = unique.

- **staff**(**staff_id** PK, full_name, role, phone)
- **categories**(**category_id** PK, name UK)
- **suppliers**(**supplier_id** PK, name, phone, address)
- **products**(**product_id** PK, sku UK, name, *category_id* FK, *supplier_id* FK, unit, cost_price, selling_price, stock_qty, reorder_level, is_active)
- **customers**(**customer_id** PK, full_name, phone UK, address, created_at)
- **orders**(**order_id** PK, *customer_id* FK nullable, *staff_id* FK, order_date, channel, status)
- **order_items**(**order_id** PK+FK, **product_id** PK+FK, quantity, unit_price)
- **payments**(**payment_id** PK, *order_id* FK, amount, method, paid_at)
- **purchases**(**purchase_id** PK, *supplier_id* FK, purchase_date)
- **purchase_items**(**purchase_id** PK+FK, **product_id** PK+FK, quantity, unit_cost, expiry_date)
- **stock_movements**(**movement_id** PK, *product_id* FK, change_qty, reason, reference_id, created_at)
- **low_stock_alerts**(**alert_id** PK, *product_id* FK, stock_at_alert, alerted_at)

## 4. Keys and Constraints Used (and why)

| Constraint | Where | Why it matters |
|---|---|---|
| Primary key (auto-numbered) | Every table | Gives every row a unique identity. |
| Composite primary key | `order_items`, `purchase_items` | The same product cannot be entered twice on one order. |
| Foreign keys | e.g. `orders.customer_id` | Prevents "orphan" records, such as an order for a customer who does not exist. |
| `ON DELETE RESTRICT / SET NULL / CASCADE` | Various | RESTRICT blocks deleting a category that still has products; SET NULL keeps an order if a customer is deleted; CASCADE deletes an order's items together with the order. |
| `CHECK (stock_qty >= 0)` | `products` | The database itself refuses to oversell. |
| `CHECK (selling_price >= cost_price)` | `products` | Stops a selling price below cost being entered by mistake. |
| `CHECK (... IN (...))` | channel, status, method, role | Only allowed values can be stored (no typos like "whatsap"). |
| `UNIQUE` | `sku`, `customers.phone`, `categories.name` | No duplicates. |
| `NOT NULL` | Essential columns | Required data cannot be left blank. |

## 5. Normalisation Explanation

**Normalisation** means organising data so each fact is stored once, which removes duplication and prevents contradictions.

**Starting point (unnormalised):** imagine your sales notebook copied into one big spreadsheet:

| order | customer | phone | date | items | prices | channel |
|---|---|---|---|---|---|---|
| 1 | Chioma | 0803... | 2 Sep | Flour x2, Sugar x2 | 1800, 1900 | walk-in |

Problems: several products squeezed into one cell, the customer's name and phone repeated on every order, and a changed phone number must be edited in many places.

**First Normal Form (1NF):** every cell holds exactly one value, and there are no repeating groups. We split the items so each product on an order is its own row. This gave us the `order_items` table.

**Second Normal Form (2NF):** in a table with a combined key such as (order_id, product_id), every other column must depend on the *whole* key. A product's `name` depends only on `product_id`, not on the order, so we moved it to `products`. Otherwise the product name would be repeated on every order line, and renaming a product would require many edits.

**Third Normal Form (3NF):** non-key columns must depend on the key and nothing else. A customer's phone depends on the customer, not on the order, so it lives in `customers`. A category name depends on the category, not the product, so it lives in `categories`. Supplier details live in `suppliers`.

**Deliberate design choices to mention in your documentation:**
- `order_items.unit_price` is stored even though `products.selling_price` exists. This is *intentional*: prices change over time, and an old receipt must keep the price actually charged (a historical fact, not a duplicate).
- The order total is **not** stored. It is calculated in the view `v_order_totals`, so it can never disagree with the items.

## 6. How to Run

```bash
createdb -U postgres bakery_store          # or create it in pgAdmin
psql -U postgres -d bakery_store -f schema.sql
psql -U postgres -d bakery_store -f seed_data.sql
```

## 7. Evidence to Capture (screenshots)

1. The ER diagram (`er-diagram.png`).
2. pgAdmin or psql showing all tables created (`\dt` in psql).
3. The sanity-check output at the end of `seed_data.sql`.
4. One deliberate constraint failure, for example: `UPDATE products SET stock_qty = -5 WHERE product_id = 1;` (shows the CHECK constraint in action).

