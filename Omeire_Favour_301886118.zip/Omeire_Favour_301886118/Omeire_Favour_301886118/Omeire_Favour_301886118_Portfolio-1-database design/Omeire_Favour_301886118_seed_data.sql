INSERT INTO staff (full_name, role, phone) VALUES
 ('Favour Omeire',     'owner',     '08010000001'),   -- staff_id 1
 ('Precious Omeire',  'attendant', '08010000002');   -- staff_id 2

INSERT INTO categories (name) VALUES
 ('Flour & Grains'),          -- 1
 ('Sugar & Sweeteners'),      -- 2
 ('Oil & Dairy'),             -- 3
 ('Baking Essentials'),       -- 4
 ('Flavourings & Colouring'), -- 5
 ('Packaging'),               -- 6
 ('Provisions');              -- 7

INSERT INTO suppliers (name, phone, address) VALUES
 ('Chioma Wholesale Bakes',  '08020000001', 'Owerri'),   -- 1
 ('Grace and Mercy Wholesale','08020000002', 'Cherubim Junction'), -- 2
 ('The Kings Provision Store',  '08020000003', 'Rotobi Market'); -- 3

INSERT INTO products (sku, name, category_id, supplier_id, unit, cost_price, selling_price, stock_qty, reorder_level) VALUES
 ('FLR-001','Wheat Flour 1kg',          1,1,'pack',   2930,   3600, 120, 30),  -- 1
 ('SUG-001','Granulated Sugar 1kg',     2,1,'pack',    700,   1000,  90, 30),  -- 2
 ('FAT-001','Margarine 1kg',            3,2,'tub',     1700,  2800,  60, 20),  -- 3
 ('BKE-001','Baking Powder 500g',       4,2,'tin',     1700,  3400,   8, 15),  -- 4  (already low)
 ('BKE-002','Instant Yeast 500g',       4,2,'pack',    3000,  4200,  25, 10),  -- 5
 ('FLV-001','Vanilla Flavour 50ml',     5,3,'bottle',  375,   500,   40, 10),  -- 6
 ('FLV-002','Cocoa Powder 200g',        5,3,'pack',    2000,  3500,  18, 10),  -- 7
 ('PKG-001','Cake Box (pack of 10)',    6,3,'pack',    2500,  3500,  35, 10),  -- 8
 ('PRV-001','Tomato Paste 400g',        7,1,'tin',     900,   1700,  70, 20),  -- 9
 ('PRV-002','Instant Noodles (carton)', 7,1,'carton',  12000, 16000, 12, 10),  -- 10
 ('PRV-003','Vegetable Oil 1.5L',       7,1,'keg',     4250,  4500,  22,  8),  -- 11
 ('FAT-002','Evaporated Milk (tin)',    3,2,'tin',     400,   600,   5, 12);  -- 12   (already low)

INSERT INTO customers (full_name, phone, address) VALUES
 ('Chioma Ukachukwu',  '08030000001',   'Road Safety Egbu'),  -- 1
 ('Tunde Bola',        '08030000002',   'Amawire Egbu'),      -- 2
 ('Kate Eze',          '08030000003',   'Reservior'),         -- 3
 ('Ibrahim Musa',      '08030000004',   'Noble Schools'),     -- 4
 ('Blessed Nkem',      '08030000005',   'Toronto Junction'),  -- 5
 ('Emeka Nwachukwu'    '08030000006',   'Wetheral'),          -- 6
 ('Smamuel Oluchi',    '08030000007',   'Owerri'),            -- 7
 ('Grace Faith',       '08030000008',   'Mbaise');            -- 8 (never orders: used for a query demo)

-- 12 sample orders (order_id 1..12). customer_id NULL = walk-in customer.
INSERT INTO orders (customer_id, staff_id, order_date, channel, status) VALUES
 (1,   1, '2026-09-02 10:15+01', 'walk-in',  'completed'),  -- 1
 (2,   1, '2026-09-05 14:30+01', 'delivery', 'completed'),  -- 2
 (NULL,2, '2026-09-07 09:05+01', 'walk-in',  'completed'),  -- 3
 (3,   1, '2026-09-10 16:45+01', 'delivery', 'completed'),  -- 4
 (4,   1, '2026-09-14 11:20+01', 'whatsapp', 'completed'),  -- 5
 (1,   2, '2026-09-20 13:00+01', 'walk-in',  'completed'),  -- 6
 (5,   1, '2026-09-25 17:10+01', 'whatsapp', 'completed'),  -- 7
 (2,   1, '2026-10-03 12:40+01', 'whatsapp', 'completed'),  -- 8
 (6,   2, '2026-10-08 10:00+01', 'walk-in',  'cancelled'),  -- 9
 (3,   1, '2026-10-15 15:25+01', 'delivery', 'completed'),  -- 10
 (7,   1, '2026-10-22 18:00+01', 'whatsapp', 'pending'),    -- 11
 (1,   2, '2026-11-05 09:30+01', 'walk-in',  'completed');  -- 12

-- (order_id, product_id, quantity, unit_price)
INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
 (1,1,2,3600),(1,2,2,1000),
 (2,3,3,2800),(2,6,1,500),
 (3,4,2,3400),
 (4,1,5,3600),(4,2,5,1000),(4,5,1,4200),
 (5,8,4,3500),(5,7,2,3500),
 (6,9,6,1700),(6,10,1,7500),
 (7,11,2,4500),(7,3,2,2800),
 (8,1,3,3600),(8,4,3,3400),(8,6,2,500),
 (9,12,10,600),
 (10,5,2,4200),(10,7,1,3500),
 (11,2,4,1000),(11,3,1,2800),
 (12,8,2,3500),(12,9,2,1700);

-- Payments for completed orders only (cash for walk-ins, bank transfer otherwise)
INSERT INTO payments (order_id, amount, method, paid_at)
SELECT o.order_id, SUM(oi.quantity * oi.unit_price),
       CASE WHEN o.channel = 'walk-in' THEN 'cash' ELSE 'transfer' END,
       o.order_date
FROM orders o JOIN order_items oi ON oi.order_id = o.order_id
WHERE o.status = 'completed'
GROUP BY o.order_id, o.channel, o.order_date;

-- Stock purchases, with expiry dates for perishables
INSERT INTO purchases (supplier_id, purchase_date) VALUES
 (1,'2026-08-20'), (2,'2026-09-01'), (3,'2026-10-10');   -- purchase_id 1,2,3

INSERT INTO purchase_items (purchase_id, product_id, quantity, unit_cost, expiry_date) VALUES
 (1,1,100,1400,'2027-03-01'),(1,2,100,1500,'2027-06-01'),(1,9,80,900,'2027-08-01'),
 (2,3,60,1800,'2026-12-01'),(2,4,30,500,'2026-12-15'),(2,5,30,3500,'2027-02-01'),
 (3,6,40,600,'2027-10-01'),(3,7,20,2200,'2027-05-01'),(3,8,40,2500,NULL);

-- Quick sanity check: counts should read 12 products, 8 customers, 12 orders
SELECT (SELECT COUNT(*) FROM products)  AS products,
       (SELECT COUNT(*) FROM customers) AS customers,
       (SELECT COUNT(*) FROM orders)    AS orders,
       (SELECT COUNT(*) FROM order_items) AS order_lines;
