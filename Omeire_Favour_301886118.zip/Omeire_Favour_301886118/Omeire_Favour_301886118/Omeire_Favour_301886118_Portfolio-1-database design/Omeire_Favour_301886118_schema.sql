-- =====================================================================
-- schema.sql  |  Portfolio 1: Database Design and Modelling
-- Case study: Favoured Marketplace - baking supplies & provisions retail
-- Database  : PostgreSQL 14+ (create an empty database called bakery_store first)
-- How to run: psql -U postgres -d bakery_store -f schema.sql
-- =====================================================================
-- Think of each TABLE as one sheet in an Excel workbook.
--   PRIMARY KEY  = the column that uniquely identifies each row (like an ID number)
--   FOREIGN KEY  = a column that points to a row in another table (like a link)
--   CHECK        = a rule the data must obey (e.g. quantity must be above 0)
--   UNIQUE       = no two rows may have the same value
--   NOT NULL     = the cell cannot be left empty
-- =====================================================================

-- Allows you to re-run this file safely: it removes old copies first.
DROP VIEW     IF EXISTS v_order_totals;
DROP TABLE    IF EXISTS low_stock_alerts, stock_movements, purchase_items, purchases,
                        payments, order_items, orders, customers, products,
                        suppliers, categories, staff CASCADE;
DROP FUNCTION IF EXISTS fn_low_stock_alert();

-- 1) STAFF: people who record sales (owner, shop attendant, delivery person)
CREATE TABLE staff (
    staff_id   INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,   -- auto-numbered 1,2,3...
    full_name  VARCHAR(100) NOT NULL,
    role       VARCHAR(30)  NOT NULL CHECK (role IN ('owner','attendant','delivery')),
    phone      VARCHAR(20)
);

-- 2) CATEGORIES: groups of products (Flour, Sugar, Milo...)
CREATE TABLE categories (
    category_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name        VARCHAR(60) NOT NULL UNIQUE
);

-- 3) SUPPLIERS: where stock is gotten from (Chioma Wholesale Bakes)
CREATE TABLE suppliers (
    supplier_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    phone       VARCHAR(20),
    address     TEXT
);

-- 4) PRODUCTS: everything to be sold (Baking Products and Provision)
CREATE TABLE products (
    product_id    INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    sku           VARCHAR(20)  NOT NULL UNIQUE,                 -- personal product code
    name          VARCHAR(120) NOT NULL,
    category_id   INT NOT NULL REFERENCES categories(category_id) ON DELETE RESTRICT,
    supplier_id   INT NOT NULL REFERENCES suppliers(supplier_id)  ON DELETE RESTRICT,
    unit          VARCHAR(20)  NOT NULL,                        -- pack, tin, carton...
    cost_price    NUMERIC(12,2) NOT NULL CHECK (cost_price >= 0),     -- what business owner pays (NGN)
    selling_price NUMERIC(12,2) NOT NULL CHECK (selling_price >= 0),  -- what customers pay (NGN)
    stock_qty     INT NOT NULL DEFAULT 0  CHECK (stock_qty >= 0),     -- can NEVER go negative
    reorder_level INT NOT NULL DEFAULT 10 CHECK (reorder_level >= 0), -- "time to restock" line
    is_active     BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT chk_price_not_below_cost CHECK (selling_price >= cost_price)
);

-- 5) CUSTOMERS: regular buyers (walk-in strangers need no record)
CREATE TABLE customers (
    customer_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    full_name   VARCHAR(100) NOT NULL,
    phone       VARCHAR(20)  NOT NULL UNIQUE,   -- WhatsApp number indicates the customer
    address     TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6) ORDERS: one row per sale (the "header" of a receipt)
CREATE TABLE orders (
    order_id    INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    customer_id INT REFERENCES customers(customer_id) ON DELETE SET NULL, -- NULL = walk-in
    staff_id    INT NOT NULL REFERENCES staff(staff_id),
    order_date  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    channel     VARCHAR(20) NOT NULL CHECK (channel IN ('walk-in','whatsapp','delivery')),
    status      VARCHAR(20) NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending','completed','cancelled'))
);

-- 7) ORDER_ITEMS: the lines on a receipt (which products, how many, at what price)
--    The PRIMARY KEY uses TWO columns: the same product cannot appear twice on one order.
CREATE TABLE order_items (
    order_id   INT NOT NULL REFERENCES orders(order_id)     ON DELETE CASCADE,
    product_id INT NOT NULL REFERENCES products(product_id),
    quantity   INT NOT NULL CHECK (quantity > 0),
    unit_price NUMERIC(12,2) NOT NULL CHECK (unit_price >= 0),  -- price AT THE TIME of sale
    PRIMARY KEY (order_id, product_id)
);

-- 8) PAYMENTS: money received for an order
CREATE TABLE payments (
    payment_id INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    order_id   INT NOT NULL REFERENCES orders(order_id) ON DELETE CASCADE,
    amount     NUMERIC(12,2) NOT NULL CHECK (amount > 0),
    method     VARCHAR(20) NOT NULL CHECK (method IN ('cash','transfer','pos','card')),
    paid_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 9) PURCHASES: stock you buy from suppliers (header)
CREATE TABLE purchases (
    purchase_id   INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    supplier_id   INT NOT NULL REFERENCES suppliers(supplier_id),
    purchase_date DATE NOT NULL DEFAULT CURRENT_DATE
);

-- 10) PURCHASE_ITEMS: lines of a purchase, including the expiry date of that batch
CREATE TABLE purchase_items (
    purchase_id INT NOT NULL REFERENCES purchases(purchase_id) ON DELETE CASCADE,
    product_id  INT NOT NULL REFERENCES products(product_id),
    quantity    INT NOT NULL CHECK (quantity > 0),
    unit_cost   NUMERIC(12,2) NOT NULL CHECK (unit_cost >= 0),
    expiry_date DATE,                                  -- empty for non-perishables
    PRIMARY KEY (purchase_id, product_id)
);

-- 11) STOCK_MOVEMENTS: an audit trail - every increase/decrease of stock is logged
CREATE TABLE stock_movements (
    movement_id  INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    product_id   INT NOT NULL REFERENCES products(product_id),
    change_qty   INT NOT NULL CHECK (change_qty <> 0),   -- negative = stock out, positive = stock in
    reason       VARCHAR(30) NOT NULL
                 CHECK (reason IN ('sale','purchase','adjustment','expiry_writeoff')),
    reference_id INT,                                    -- the related order/purchase number
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 12) LOW_STOCK_ALERTS: filled automatically by a TRIGGER (see below)
CREATE TABLE low_stock_alerts (
    alert_id       INT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    product_id     INT NOT NULL REFERENCES products(product_id),
    stock_at_alert INT NOT NULL,
    alerted_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------------------------
-- VIEW: a saved query that behaves like a table. Order totals are calculated
-- here instead of being stored, so they can never disagree with the items.
-- ---------------------------------------------------------------------
CREATE VIEW v_order_totals AS
SELECT o.order_id, o.customer_id, o.order_date, o.channel, o.status,
       SUM(oi.quantity * oi.unit_price) AS order_total
FROM orders o
JOIN order_items oi ON oi.order_id = o.order_id
GROUP BY o.order_id;

-- ---------------------------------------------------------------------
-- TRIGGER: automatic action. When a product's stock FALLS to/below its
-- reorder level, a row is added to low_stock_alerts without anyone asking.
-- ---------------------------------------------------------------------
CREATE FUNCTION fn_low_stock_alert() RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO low_stock_alerts (product_id, stock_at_alert)
    VALUES (NEW.product_id, NEW.stock_qty);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_low_stock
AFTER UPDATE OF stock_qty ON products
FOR EACH ROW
WHEN (NEW.stock_qty <= NEW.reorder_level AND OLD.stock_qty > OLD.reorder_level)
EXECUTE FUNCTION fn_low_stock_alert();
