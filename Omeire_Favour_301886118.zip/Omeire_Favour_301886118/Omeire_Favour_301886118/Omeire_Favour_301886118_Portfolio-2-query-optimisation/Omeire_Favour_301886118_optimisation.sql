-- optimisation.sql  |  Portfolio 2: Optimisation (making queries faster)

-- ---------- STEP 0: create bulk test data (takes ~10-60 seconds) ----------
-- 2,000 extra customers (customer_id 9..2008)
INSERT INTO customers (full_name, phone)
SELECT 'Test Customer ' || g, '09' || LPAD(g::text, 9, '0')
FROM generate_series(1, 2000) AS g;

-- 100,000 extra orders spread over the last 2 years
INSERT INTO orders (customer_id, staff_id, order_date, channel, status)
SELECT 9 + floor(random() * 2000)::int,
       1 + floor(random() * 2)::int,
       NOW() - random() * 730 * INTERVAL '1 day',
       (ARRAY['walk-in','whatsapp','delivery'])[1 + floor(random() * 3)::int],
       'completed'
FROM generate_series(1, 100000);

-- 2 random products per bulk order (the 12 original orders are skipped)
INSERT INTO order_items (order_id, product_id, quantity, unit_price)
SELECT o.order_id, p.product_id, 1 + floor(random() * 5)::int, p.selling_price
FROM orders o
CROSS JOIN LATERAL (SELECT product_id, selling_price
                    FROM products ORDER BY random() LIMIT 2) p
WHERE o.order_id > 12;

ANALYZE;  -- refresh the database's statistics so the planner makes good choices

-- ---------- STEP 1: BASELINE (no index yet) ----------
-- Question: "Show all orders from customer 500 this year"
EXPLAIN (ANALYZE, BUFFERS)
SELECT order_id, order_date, channel
FROM orders
WHERE customer_id = 500
  AND order_date >= '2026-01-01';
-- LOOK FOR:  "Seq Scan on orders"  (reads the whole table)
-- RECORD:    "Execution Time: ___ ms"  and  "Rows Removed by Filter: ___"

-- ---------- STEP 2: ADD AN INDEX ----------
CREATE INDEX idx_orders_customer_date ON orders (customer_id, order_date);
ANALYZE orders;

-- ---------- STEP 3: RE-RUN THE SAME QUERY ----------
EXPLAIN (ANALYZE, BUFFERS)
SELECT order_id, order_date, channel
FROM orders
WHERE customer_id = 500
  AND order_date >= '2026-01-01';
-- LOOK FOR:  "Index Scan" or "Bitmap Index Scan using idx_orders_customer_date"
-- RECORD:    the new Execution Time and compare with Step 1.

-- ---------- STEP 4: A JOIN QUERY (second experiment) ----------
EXPLAIN (ANALYZE, BUFFERS)
SELECT p.name, SUM(oi.quantity * oi.unit_price) AS revenue
FROM order_items oi
JOIN products p ON p.product_id = oi.product_id
WHERE oi.product_id = 5
GROUP BY p.name;

CREATE INDEX idx_order_items_product ON order_items (product_id);
ANALYZE order_items;

-- ---------- STEP 5: see the index sizes (trade-off: indexes use disk space) ----------
SELECT indexname, pg_size_pretty(pg_relation_size(indexname::regclass)) AS size
FROM pg_indexes
WHERE tablename IN ('orders', 'order_items');

-- ---------- CLEAN UP (optional): remove the bulk data when finished ----------
-- DELETE FROM orders    WHERE order_id    > 12;   -- order_items are deleted automatically
-- DELETE FROM customers WHERE customer_id > 8;
-- DROP INDEX IF EXISTS idx_orders_customer_date, idx_order_items_product;
