-- queries.sql  |  Portfolio 2: Query Processing (the business questions)

-- Q1. Which 5 products earn the most money? (JOIN + GROUP BY + ORDER BY)
SELECT p.name,
       SUM(oi.quantity)                  AS units_sold,
       SUM(oi.quantity * oi.unit_price)  AS revenue
FROM order_items oi
JOIN products p ON p.product_id = oi.product_id
JOIN orders   o ON o.order_id   = oi.order_id
WHERE o.status = 'completed'
GROUP BY p.product_id, p.name
ORDER BY revenue DESC
LIMIT 5;

-- Q2. How much did the shop sell each month?
SELECT DATE_TRUNC('month', o.order_date)::date AS month,
       COUNT(DISTINCT o.order_id)              AS number_of_orders,
       SUM(oi.quantity * oi.unit_price)        AS revenue
FROM orders o
JOIN order_items oi ON oi.order_id = o.order_id
WHERE o.status = 'completed'
GROUP BY 1
ORDER BY 1;

-- Q3. Which products need restocking now?
SELECT name, stock_qty, reorder_level, reorder_level - stock_qty AS shortfall
FROM products
WHERE stock_qty <= reorder_level AND is_active
ORDER BY shortfall DESC;

-- Q4. Which stock batches expire within the next 30 days?
SELECT p.name, pi.quantity AS qty_bought, pi.expiry_date,
       pi.expiry_date - CURRENT_DATE AS days_left
FROM purchase_items pi
JOIN products p ON p.product_id = pi.product_id
WHERE pi.expiry_date IS NOT NULL
  AND pi.expiry_date <= CURRENT_DATE + 60
ORDER BY pi.expiry_date;

-- Q5. Profit and profit margin per product
SELECT p.name,
       SUM(oi.quantity * (oi.unit_price - p.cost_price)) AS profit,
       ROUND(100.0 * SUM(oi.quantity * (oi.unit_price - p.cost_price))
                   / SUM(oi.quantity * oi.unit_price), 1) AS margin_percent
FROM order_items oi
JOIN products p ON p.product_id = oi.product_id
JOIN orders   o ON o.order_id   = oi.order_id
WHERE o.status = 'completed'
GROUP BY p.product_id, p.name
ORDER BY profit DESC;

-- Q6. Rank customers by how much they have spent (WINDOW FUNCTION)
SELECT c.full_name,
       SUM(oi.quantity * oi.unit_price) AS total_spent,
       RANK() OVER (ORDER BY SUM(oi.quantity * oi.unit_price) DESC) AS spend_rank
FROM customers c
JOIN orders o       ON o.customer_id = c.customer_id
JOIN order_items oi ON oi.order_id   = o.order_id
WHERE o.status = 'completed'
GROUP BY c.customer_id, c.full_name
ORDER BY spend_rank;

-- Q7. Which registered customers have NEVER bought anything? (LEFT JOIN)
SELECT c.full_name, c.phone
FROM customers c
LEFT JOIN orders o ON o.customer_id = c.customer_id
WHERE o.order_id IS NULL;

-- Q8. Customers who spent MORE than the average customer (CTE + subquery)
WITH customer_totals AS (
    SELECT o.customer_id, SUM(oi.quantity * oi.unit_price) AS total
    FROM orders o
    JOIN order_items oi ON oi.order_id = o.order_id
    WHERE o.customer_id IS NOT NULL AND o.status = 'completed'
    GROUP BY o.customer_id
)
SELECT c.full_name, ct.total
FROM customer_totals ct
JOIN customers c ON c.customer_id = ct.customer_id
WHERE ct.total > (SELECT AVG(total) FROM customer_totals)
ORDER BY ct.total DESC;

-- Q9. Sales by channel using the saved VIEW from Portfolio 1
SELECT channel, COUNT(*) AS orders, SUM(order_total) AS revenue
FROM v_order_totals
WHERE status = 'completed'
GROUP BY channel
ORDER BY revenue DESC;
