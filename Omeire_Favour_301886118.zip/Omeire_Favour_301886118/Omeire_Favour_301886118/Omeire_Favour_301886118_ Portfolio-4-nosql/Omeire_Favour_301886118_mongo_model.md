# Portfolio 4: NoSQL and Advanced Data Models

## 1. Why NoSQL for this shop?

The relational design in Portfolio 1 is the right *core* system because money and stock need strict rules (constraints, transactions). But some parts of the business fit NoSQL better:

| Business need | Why the relational model struggles | NoSQL fit |
|---|---|---|
| **Products with different attributes** (flour has weight, vanilla has volume and flavour, cake boxes have size and colour) | A relational table needs a column for every possible attribute, leaving many empty cells, or extra "attribute" tables that need complex joins. | **Document database (MongoDB)**: each product document holds only its own attributes. |
| **Whole receipt in one read** (WhatsApp order history, delivery tracking, order confirmation pages) | Needs 4 to 5 table joins every time. | **Document database**: order, items, delivery and payment embedded in one document. |
| **Temporary shopping cart or WhatsApp chat session** | Rows that live for minutes do not justify permanent relational tables. | **Key-value store (Redis)**: key = customer phone, value = cart contents, with an expiry time. |
| **"Customers who bought X also bought Y" recommendations** | Needs repeated self-joins, which are slow and hard to write. | **Graph database (Neo4j)**: products and customers are nodes, "BOUGHT" is a relationship. |


## 2. The four NoSQL families, using your shop

| Type | Example product | Shop example |
|---|---|---|
| Document | MongoDB | `orders` collection with embedded items (**implemented in `mongo_scripts.js`**) |
| Key-value | Redis | `cart:08030000002` → `{"flour":2,"sugar":1}` expires in 30 minutes |
| Column-family | Cassandra | Sales events per day, written at high speed (e.g. thousands of POS events) |
| Graph | Neo4j | `(Chioma)-[:BOUGHT]->(Flour)<-[:BOUGHT]-(Tunde)` |

Only one implementation is required. The assignment says "document/key-value/column/graph example", so MongoDB (document) is enough. Showing the key-value and graph ideas below is a bonus.

## 3. Document Model (implemented)

Embedded vs. referenced design decision:

```
products   { _id, sku, name, category, price, stock, attributes:{...} }        (own collection)
customers  { _id, full_name, phone, address }                                  (own collection)
orders     { _id, order_date, channel, status,
             customer:{customer_id,name,phone},                                (copied snapshot)
             items:[{product_id,name,qty,unit_price}, ...],                    (EMBEDDED)
             delivery:{...}, payment:{...} }                                   (EMBEDDED)
```

- **Embed** the items inside the order because they are always read together and never exist alone.
- **Reference by ID** for products and customers because they change independently and are shared across many orders.
- **Copy (snapshot)** the name and price into the item, like a printed receipt, so history stays correct when prices change.

## 4. Relational vs Document: side by side

| Question | PostgreSQL | MongoDB |
|---|---|---|
| Get a whole receipt | JOIN orders + order_items + payments + products | One `findOne` |
| Add a new product attribute (e.g. "gluten_free") | `ALTER TABLE` or a new table | Just include the field in new documents |
| Sell stock safely with rules | `CHECK` constraints, multi-table ACID transactions | Possible (`$inc` is atomic per document) but cross-document rules are the application's job |
| Revenue per product | Simple `GROUP BY` | `aggregate` pipeline (`$unwind`, `$group`) |
| Data consistency | Very strong | Strong per document; flexible, so mistakes are easier |

## 5. Key-value example (concept, optional bonus)

With Redis:
```
SET cart:08030000002 '{"flour":2,"sugar":1}' EX 1800
GET cart:08030000002
TTL cart:08030000002
```
`EX 1800` makes the cart disappear after 30 minutes automatically. You could implement this by installing Redis (or using Docker: `docker run -p 6379:6379 redis`) and screenshotting the commands.

## 6. Graph example (concept, optional bonus)

```
CREATE (c1:Customer {name:'Chioma'}), (c2:Customer {name:'Tunde'}),
       (p:Product {name:'Wheat Flour'}), (s:Product {name:'Sugar'})
CREATE (c1)-[:BOUGHT]->(p), (c1)-[:BOUGHT]->(s), (c2)-[:BOUGHT]->(p)

// Recommend to Tunde what others who bought flour also bought:
MATCH (:Customer {name:'Tunde'})-[:BOUGHT]->(p)<-[:BOUGHT]-(other)-[:BOUGHT]->(rec)
WHERE NOT (:Customer {name:'Tunde'})-[:BOUGHT]->(rec)
RETURN DISTINCT rec.name
```