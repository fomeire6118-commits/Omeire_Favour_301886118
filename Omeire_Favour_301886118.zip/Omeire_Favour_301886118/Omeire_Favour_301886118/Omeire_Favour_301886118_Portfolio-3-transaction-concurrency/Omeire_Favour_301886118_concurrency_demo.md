# Concurrency Demonstration (PostgreSQL)

**Concurrency** means two people using the database at the same moment, for example two attendants selling the last tins of Cocoa Powder at the same time. Without controls, the database can give wrong answers.

## Setup
Open **two** connections to `bakery_store`:
- **Terminal A**: `psql -U postgres -d bakery_store`
- **Terminal B**: a second `psql` window (or two Query Tool tabs in pgAdmin; each tab is its own session).

Reset between demos if needed: `UPDATE products SET stock_qty = 18, selling_price = 3500 WHERE product_id = 7;`

---

## Demo 1: The Lost Update problem (what goes WRONG)

Product 7 (Cocoa Powder) has 18 in stock. A sells 3, B sells 5. Correct final stock = **10**.

| Step | Terminal A | Terminal B |
|---|---|---|
| 1 | `BEGIN;` | `BEGIN;` |
| 2 | `SELECT stock_qty FROM products WHERE product_id = 7;` → 18 | `SELECT stock_qty FROM products WHERE product_id = 7;` → 18 |
| 3 | `UPDATE products SET stock_qty = 18 - 3 WHERE product_id = 7;` | |
| 4 | `COMMIT;` (stock is now 15) | |
| 5 | | `UPDATE products SET stock_qty = 18 - 5 WHERE product_id = 7;` |
| 6 | | `COMMIT;` |
| 7 | `SELECT stock_qty FROM products WHERE product_id = 7;` → **13 (WRONG, should be 10)** | |

**Why:** both read 18, calculated in their own heads, and B's write silently overwrote A's. A's sale of 3 was "lost".

## Demo 2: Fix with row locking (`SELECT ... FOR UPDATE`)

Reset stock to 18 first.

| Step | Terminal A | Terminal B |
|---|---|---|
| 1 | `BEGIN;` | `BEGIN;` |
| 2 | `SELECT stock_qty FROM products WHERE product_id = 7 FOR UPDATE;` → 18 (row now locked) | |
| 3 | | `SELECT stock_qty FROM products WHERE product_id = 7 FOR UPDATE;` → **waits (blocked)** |
| 4 | `UPDATE products SET stock_qty = 18 - 3 WHERE product_id = 7; COMMIT;` | B unblocks and now reads **15** |
| 5 | | `UPDATE products SET stock_qty = 15 - 5 WHERE product_id = 7; COMMIT;` |
| 6 | Final stock → **10 (correct)** | |

**Why:** the lock forces B to wait until A has finished, so B always works with up-to-date data. This is exactly what `place_order()` does.

## Demo 3: Fix with an atomic update (simplest)

`UPDATE products SET stock_qty = stock_qty - 5 WHERE product_id = 7;`

The database does the read-and-write as one indivisible step, so no lost update. Mention this as the simplest option and `FOR UPDATE` as the choice when you must check conditions first (like "is there enough stock?").

## Demo 4: Isolation levels (non-repeatable read)

**Isolation level** = how much one transaction can see of another's changes.

*Part 1: READ COMMITTED (PostgreSQL default)*

| Step | Terminal A | Terminal B |
|---|---|---|
| 1 | `BEGIN;` | |
| 2 | `SELECT selling_price FROM products WHERE product_id = 1;` → 3600 | |
| 3 | | `UPDATE products SET selling_price = 3800 WHERE product_id = 1;` (auto-commits) |
| 4 | `SELECT selling_price FROM products WHERE product_id = 1;` → **3800** (changed mid-transaction = non-repeatable read) | |
| 5 | `COMMIT;` | |

Reset: `UPDATE products SET selling_price = 3600 WHERE product_id = 1;`

*Part 2: REPEATABLE READ*

| Step | Terminal A | Terminal B |
|---|---|---|
| 1 | `BEGIN ISOLATION LEVEL REPEATABLE READ;` | |
| 2 | `SELECT selling_price FROM products WHERE product_id = 1;` → 3600 | |
| 3 | | `UPDATE products SET selling_price = 3800 WHERE product_id = 1;` |
| 4 | `SELECT selling_price FROM products WHERE product_id = 1;` → **still 3600** (consistent snapshot) | |
| 5 | `COMMIT;` then select again → 3800 | |

Reset the price again afterwards.

| Isolation level | Dirty read | Non-repeatable read | Phantom read |
|---|---|---|---|
| Read Uncommitted (acts as Read Committed in PostgreSQL) | No | Possible | Possible |
| Read Committed (default) | No | Possible | Possible |
| Repeatable Read | No | No | No (in PostgreSQL) |
| Serializable | No | No | No |

## Demo 5: Deadlock

A deadlock is two people each holding something the other needs, so both wait forever. PostgreSQL detects it and cancels one.

| Step | Terminal A | Terminal B |
|---|---|---|
| 1 | `BEGIN;` | `BEGIN;` |
| 2 | `UPDATE products SET reorder_level = 31 WHERE product_id = 1;` | `UPDATE products SET reorder_level = 31 WHERE product_id = 2;` |
| 3 | `UPDATE products SET reorder_level = 31 WHERE product_id = 2;` (waits for B) | |
| 4 | | `UPDATE products SET reorder_level = 31 WHERE product_id = 1;` → **ERROR: deadlock detected** (one session is rolled back) |
| 5 | The surviving session can `COMMIT;` | The cancelled session must `ROLLBACK;` |
