-- transactions.sql  |  Portfolio 3: Transactions
-- A TRANSACTION is a group of steps that must ALL succeed or ALL be undone.

-- ---------- PART A: a successful sale (COMMIT) ----------
-- Check stock BEFORE:
SELECT product_id, name, stock_qty FROM products WHERE product_id = 1;

BEGIN;
    INSERT INTO orders (customer_id, staff_id, channel, status)
    VALUES (1, 1, 'walk-in', 'completed');

    INSERT INTO order_items (order_id, product_id, quantity, unit_price)
    VALUES (currval(pg_get_serial_sequence('orders','order_id')), 1, 2, 3600);

    UPDATE products SET stock_qty = stock_qty - 2 WHERE product_id = 1;

    INSERT INTO stock_movements (product_id, change_qty, reason, reference_id)
    VALUES (1, -2, 'sale', currval(pg_get_serial_sequence('orders','order_id')));

    INSERT INTO payments (order_id, amount, method)
    VALUES (currval(pg_get_serial_sequence('orders','order_id')), 7200, 'cash');
COMMIT;

-- Check stock AFTER (should be 2 less) and view the new order:
SELECT product_id, name, stock_qty FROM products WHERE product_id = 1;
SELECT * FROM v_order_totals ORDER BY order_id DESC LIMIT 1;

-- ---------- PART B: a failed sale (ROLLBACK) ----------
-- Product 4 has only 8 in stock. Trying to sell 999 breaks CHECK (stock_qty >= 0).
BEGIN;
    UPDATE products SET stock_qty = stock_qty - 999 WHERE product_id = 4;
    -- ERROR: new row violates check constraint "products_stock_qty_check"
ROLLBACK;   -- the transaction is now unusable; ROLLBACK cleans it up

SELECT product_id, name, stock_qty FROM products WHERE product_id = 4;  -- still 8

-- ---------- PART C: a manual ROLLBACK (changing your mind) ----------
BEGIN;
    SELECT COUNT(*) AS items_before FROM order_items WHERE order_id = 1;   -- 2
    DELETE FROM order_items WHERE order_id = 1;
    SELECT COUNT(*) AS items_inside_transaction FROM order_items WHERE order_id = 1;  -- 0
ROLLBACK;
SELECT COUNT(*) AS items_after_rollback FROM order_items WHERE order_id = 1;  -- 2 again

-- ---------- PART D: SAVEPOINT (undo only part of a transaction) ----------
BEGIN;
    UPDATE products SET selling_price = 3700 WHERE product_id = 1;     -- keep this
    SAVEPOINT before_sugar_change;
    UPDATE products SET selling_price = 1 WHERE product_id = 2;        -- a mistake!
    ROLLBACK TO SAVEPOINT before_sugar_change;                         -- undo only the mistake
COMMIT;
SELECT product_id, name, selling_price FROM products WHERE product_id IN (1,2);
-- Put the price back so later demos match the notes:
UPDATE products SET selling_price = 3600 WHERE product_id = 1;

-- ---------- PART E: a reusable "place order" function ----------
-- A function runs as ONE transaction automatically: if any step raises an
-- error, every change made inside it is undone.
-- FOR UPDATE locks the product row so two people cannot sell the last items
-- at the same time (see concurrency_demo.md).
CREATE OR REPLACE FUNCTION place_order(
    p_customer_id INT, p_staff_id INT, p_channel TEXT,
    p_product_id  INT, p_qty INT,      p_method  TEXT DEFAULT 'cash'
) RETURNS INT AS $$
DECLARE
    v_order_id INT;
    v_stock    INT;
    v_price    NUMERIC(12,2);
BEGIN
    SELECT stock_qty, selling_price INTO v_stock, v_price
    FROM products WHERE product_id = p_product_id
    FOR UPDATE;                                   -- lock this product row

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Product % does not exist', p_product_id;
    END IF;
    IF v_stock < p_qty THEN
        RAISE EXCEPTION 'Insufficient stock for product %: have %, need %',
                        p_product_id, v_stock, p_qty;
    END IF;

    INSERT INTO orders (customer_id, staff_id, channel, status)
    VALUES (p_customer_id, p_staff_id, p_channel, 'completed')
    RETURNING order_id INTO v_order_id;

    INSERT INTO order_items (order_id, product_id, quantity, unit_price)
    VALUES (v_order_id, p_product_id, p_qty, v_price);

    UPDATE products SET stock_qty = stock_qty - p_qty WHERE product_id = p_product_id;

    INSERT INTO stock_movements (product_id, change_qty, reason, reference_id)
    VALUES (p_product_id, -p_qty, 'sale', v_order_id);

    INSERT INTO payments (order_id, amount, method)
    VALUES (v_order_id, p_qty * v_price, p_method);

    RETURN v_order_id;
END;
$$ LANGUAGE plpgsql;

-- Successful call (product 3 = Margarine, stock 60):
SELECT place_order(2, 1, 'whatsapp', 3, 2, 'transfer') AS new_order_id;

-- Failing call (product 12 has only 5 in stock; we ask for 100):
SELECT place_order(2, 1, 'whatsapp', 12, 100, 'cash');
-- ERROR: Insufficient stock ... and NOTHING was saved. Prove it:
SELECT COUNT(*) AS orders_total FROM orders;   -- unchanged by the failed call
SELECT stock_qty FROM products WHERE product_id = 12;  -- still 5

-- ---------- PART F: the trigger from Portfolio 1 in action ----------
-- Yeast (product 5) has 25 in stock and reorder level 10. Selling 16 leaves 9,
-- which crosses the line, so the trigger writes an alert automatically.
SELECT place_order(1, 1, 'walk-in', 5, 16, 'cash');
SELECT a.alert_id, p.name, a.stock_at_alert, a.alerted_at
FROM low_stock_alerts a JOIN products p USING (product_id);
