# Advanced Database Systems Portfolio (MIT 8103)

**Student:** Favour Amarachi Omeire | **Matric No:** 2025/C/MIT/1766 | **Session:** 2026/2027, First Semester

## Selected Case Study
**Favoured Market Place**, a small retail business in Nigeria selling baking products and provisions. The database supports recording sales (walk-in, WhatsApp, delivery), tracking stock and expiry dates, managing suppliers and customers, recording payments, and producing business insights.

- **Users:** owner, shop attendants, delivery staff
- **Major data:** products, categories, suppliers, customers, orders, order items, payments, purchases, stock movements, low-stock alerts
- **Key operations:** record a sale, update stock, flag low stock and near-expiry goods, rank best sellers, measure profit and customer value

## Repository Map

| Folder | Portfolio | What is inside |
|---|---|---|
| `portfolio-1-database-design/` | Design and Modelling | Case study, ER diagram, schema, keys, constraints, normalisation, sample data |
| `portfolio-2-query-optimisation/` | Query Processing and Optimisation | Business queries, execution plans, indexing experiment, performance analysis |
| `portfolio-3-transactions-concurrency/` | Transactions and Concurrency | Commit, rollback, savepoint, transactional function, locking and isolation demos |
| `portfolio-4-nosql/` | NoSQL and Advanced Data Models | MongoDB model, scripts, suitability analysis |
| `portfolio-5-distributed-cloud/` | Distributed and Cloud | Replication, partitioning/sharding, CAP, cloud deployment |

## Technology Used
PostgreSQL (version [fill in]), pgAdmin/psql, MongoDB (version [fill in]) with mongosh, Docker, GitHub.

## How to Reproduce
1. Create database `bakery_store`; run `portfolio-1-database-design/schema.sql` then `seed_data.sql`.
2. Run `portfolio-2-query-optimisation/queries.sql`, then `optimisation.sql` step by step.
3. Run `portfolio-3-transactions-concurrency/transactions.sql` and follow `concurrency_demo.md`.
4. Run `portfolio-4-nosql/mongo_scripts.js` with mongosh.
5. Follow `portfolio-5-distributed-cloud/README.md`.

## Evidence
Screenshots are stored in a `screenshots/` subfolder inside each portfolio folder.

## Sources and Tools Acknowledged
PostgreSQL Documentation (postgresql.org/docs), MongoDB Manual (mongodb.com/docs), [add textbooks/lecture notes you used].

## AI Use Declaration
See `FINAL_DOCUMENTATION_TEMPLATE.md`.
