-- =====================================================================
-- partitioning.sql | Portfolio 5: splitting a big table into pieces
-- PARTITIONING = one logical table stored as several smaller physical tables
-- on ONE server. SHARDING = the same idea, but pieces live on DIFFERENT
-- servers. Partitioning is the easiest way to demonstrate the concept in
-- PostgreSQL, because it shows how queries only touch the pieces they need.
-- =====================================================================
DROP TABLE IF EXISTS sales_log CASCADE;

CREATE TABLE sales_log (
    log_id     BIGINT NOT NULL,
    sold_at    TIMESTAMPTZ NOT NULL,
    product_id INT NOT NULL,
    amount     NUMERIC(12,2) NOT NULL,
    PRIMARY KEY (log_id, sold_at)
) PARTITION BY RANGE (sold_at);

CREATE TABLE sales_log_2026_h1 PARTITION OF sales_log
    FOR VALUES FROM ('2026-01-01') TO ('2026-07-01');
CREATE TABLE sales_log_2026_h2 PARTITION OF sales_log
    FOR VALUES FROM ('2026-07-01') TO ('2027-01-01');

INSERT INTO sales_log (log_id, sold_at, product_id, amount)
SELECT g,
       TIMESTAMPTZ '2026-01-01' + random() * 364 * INTERVAL '1 day',
       1 + floor(random() * 12)::int,
       round((500 + random() * 10000)::numeric, 2)
FROM generate_series(1, 50000) AS g;

ANALYZE sales_log;

-- How many rows landed in each piece?
SELECT tableoid::regclass AS partition_name, COUNT(*) AS rows
FROM sales_log GROUP BY 1 ORDER BY 1;

-- PARTITION PRUNING: this query only needs the second half-year table.
EXPLAIN SELECT SUM(amount) FROM sales_log
WHERE sold_at >= '2026-09-01' AND sold_at < '2026-10-01';
-- LOOK FOR: only "sales_log_2026_h2" appears in the plan; h1 is skipped.
